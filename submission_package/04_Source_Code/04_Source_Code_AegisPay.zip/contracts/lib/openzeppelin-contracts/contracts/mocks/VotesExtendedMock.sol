// SPDX-License-Identifier: MIT

pragma solidity ^0.8.24;

import {VotesExtended} from "../governance/utils/VotesExtended.sol";
import {Time} from "../utils/types/Time.sol";
import {ERC6372Utils} from "../utils/ERC6372Utils.sol";

abstract contract VotesExtendedMock is VotesExtended {
    mapping(address voter => uint256) private _votingUnits;

    function getTotalSupply() public view returns (uint256) {
        return _getTotalSupply();
    }

    function delegate(address account, address newDelegation) public {
        return _delegate(account, newDelegation);
    }

    function _getVotingUnits(address account) internal view override returns (uint256) {
        return _votingUnits[account];
    }

    function _mint(address account, uint256 votes) internal {
        _votingUnits[account] += votes;
        _transferVotingUnits(address(0), account, votes);
    }

    function _burn(address account, uint256 votes) internal {
        _votingUnits[account] += votes;
        _transferVotingUnits(account, address(0), votes);
    }
}

abstract contract VotesExtendedTimestampMock is VotesExtendedMock {
    function clock() public view override returns (uint48) {
        return Time.timestamp();
    }

    // solhint-disable-next-line func-name-mixedcase
    function CLOCK_MODE() public view virtual override returns (string memory) {
        return ERC6372Utils.timestampClockMode(clock);
    }
}
